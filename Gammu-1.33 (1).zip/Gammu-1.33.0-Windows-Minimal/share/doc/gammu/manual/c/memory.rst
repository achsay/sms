Memory
======

.. doxygenfunction:: GSM_StringToMemoryType
.. doxygenfunction:: GSM_GetMemoryStatus
.. doxygenfunction:: GSM_GetMemory
.. doxygenfunction:: GSM_GetNextMemory
.. doxygenfunction:: GSM_SetMemory
.. doxygenfunction:: GSM_AddMemory
.. doxygenfunction:: GSM_DeleteMemory
.. doxygenfunction:: GSM_DeleteAllMemory
.. doxygenfunction:: GSM_GetSpeedDial
.. doxygenfunction:: GSM_SetSpeedDial
.. doxygenfunction:: GSM_PhonebookGetEntryName
.. doxygenfunction:: GSM_PhonebookFindDefaultNameNumberGroup
.. doxygenfunction:: GSM_EncodeVCARD
.. doxygenfunction:: GSM_DecodeVCARD
.. doxygenfunction:: GSM_FreeMemoryEntry
.. doxygenenum:: GSM_MemoryType
.. doxygenstruct:: GSM_MemoryStatus
.. doxygenenum:: GSM_EntryType
.. doxygenenum:: GSM_EntryLocation
.. doxygenstruct:: GSM_SubMemoryEntry
.. doxygenstruct:: GSM_MemoryEntry
.. doxygenstruct:: GSM_SpeedDial
.. doxygenenum:: GSM_VCardVersion
