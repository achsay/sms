Keys
====

.. doxygenfunction:: MakeKeySequence
.. doxygenfunction:: GSM_PressKey
.. doxygenenum:: GSM_KeyCode
