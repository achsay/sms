Backup
======

.. doxygenfunction:: GSM_ReadSMSBackupFile
.. doxygenfunction:: GSM_AddSMSBackupFile
.. doxygenfunction:: GSM_ClearSMSBackup
.. doxygenfunction:: GSM_FreeSMSBackup
.. doxygenfunction:: GSM_SaveBackupFile
.. doxygenfunction:: GSM_GuessBackupFormat
.. doxygenfunction:: GSM_ReadBackupFile
.. doxygenfunction:: GSM_ClearBackup
.. doxygenfunction:: GSM_FreeBackup
.. doxygenfunction:: GSM_GetBackupFormatFeatures
.. doxygenfunction:: GSM_GetBackupFileFeatures
.. doxygenstruct:: GSM_SMS_Backup
.. doxygenstruct:: GSM_Backup
.. doxygenenum:: GSM_BackupFormat
.. doxygenstruct:: GSM_Backup_Info
