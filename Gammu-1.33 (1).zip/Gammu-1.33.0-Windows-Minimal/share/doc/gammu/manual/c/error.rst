Error handling
==============

.. doxygenfunction:: GSM_ErrorString
.. doxygenfunction:: GSM_ErrorName
.. doxygenenum:: GSM_Error
