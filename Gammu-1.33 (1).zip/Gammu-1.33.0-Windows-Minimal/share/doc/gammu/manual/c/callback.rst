Callback
========

.. doxygenfunction:: GSM_SetIncomingCallCallback
.. doxygenfunction:: GSM_SetIncomingSMSCallback
.. doxygenfunction:: GSM_SetIncomingCBCallback
.. doxygenfunction:: GSM_SetIncomingUSSDCallback
.. doxygenfunction:: GSM_SetSendSMSStatusCallback
.. doxygentypedef:: IncomingCallCallback
.. doxygentypedef:: IncomingSMSCallback
.. doxygentypedef:: IncomingCBCallback
.. doxygentypedef:: IncomingUSSDCallback
.. doxygentypedef:: SendSMSStatusCallback
